// Add your Server token: Go to "Firebase console -> Project setting -> Cloud messaging -> Server key"
const String firebaseCloudserverToken = 'YOUR_FB_SERVER_KEY';//AAAAFxtLywg:APA91bFbcXfhUI2b2MagqgYnL
const String firebaseCloudvapidKey = 'YOUR_VAPID_KEY';
const String youtubeChannelLink = 'https://www.youtube.com/channel/UCLNCErWFQ6LZoaV_JKOq_lQ';

const chatInstruction = """Chat App is committed to maintaining a healthy chat, and blocks users who disseminated vegan chats or photos.

We do not provide any other services other than this application. Beware of scam or illegal website promotion.

Attempts to send obscene, offensive, racist messages or request money transactions can result in permanent suspension and criminal prosecution.""";
