//
//  NotificationService.h
//  ImageNotification
//
//  Created by enter on 2021-03-17.
//  Copyright © 2021 The Chromium Authors. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
